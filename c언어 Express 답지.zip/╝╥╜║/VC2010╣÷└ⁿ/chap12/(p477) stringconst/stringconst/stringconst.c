#include <stdio.h>
#include <string.h>

int main(void)
{
	char *p1 = "HelloWorld";
	char p2[] = "HelloWorld";

	//p1[0] = 'h';
	//strcpy(p1, "Goodbye");

	printf("p1 = %p \n", p1);
	printf("p1 = %s \n", p1);
	printf("\"HelloWorld\" �ּ�=%p \n\n", "HelloWorld");

	p1 = "Goodbye";	// ����!
	printf("p1�� \"Goodbye\"�� ����Ű���� ���� \n");
	printf("p1 = %p \n", p1);
	printf("p1 = %s \n", p1);
	printf("\"Goodbye\" �ּ�=%p \n\n", "Goodbye");

	strcpy(p2, "Goodbye");
	printf("p2 = %p \n", p2);
	printf("p2 = %s \n", p2);
	return 0;
}