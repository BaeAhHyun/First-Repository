#include <stdio.h>

int main(void)
{
	int d, o, x;

	scanf("%d %o %x", &d, &o, &x);
	printf("d=%d o=%d x=%d\n", d, o, x);

	return 0;
}