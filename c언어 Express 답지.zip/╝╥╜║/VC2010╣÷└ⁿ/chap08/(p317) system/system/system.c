#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

int main( void )
{
	system("dir");
	printf("�ƹ� Ű�� ġ����\n");
	getch();
	system("cls");

	return 0;
}