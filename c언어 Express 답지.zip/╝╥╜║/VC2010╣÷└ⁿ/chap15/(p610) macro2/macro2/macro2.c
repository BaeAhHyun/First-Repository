#include <stdio.h>
#define PRINT(exp) printf("exp = %d\n",exp);

int main(void)
{
	int x = 5;

	PRINT(x);
	return 0;
}
