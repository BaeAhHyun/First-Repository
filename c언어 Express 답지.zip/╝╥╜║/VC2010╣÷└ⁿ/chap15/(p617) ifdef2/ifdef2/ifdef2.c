#include <stdio.h>
#define LINUX

int main(void)
{
#ifdef LINUX
	//...
#else 
	//...
#endif 
       return 0;
}