#include <stdio.h>

int main(void)
{
	float x = 1e39;
	printf("x = %e\n",x);
}