#include <stdio.h>

int main(void)
{
	int x = 10;
	int y = 010;
	int z = 0x10;


	printf("x = %d\n", x);
	printf("y = %d\n", y);
	printf("z = %d\n", z);

	return 0;
}