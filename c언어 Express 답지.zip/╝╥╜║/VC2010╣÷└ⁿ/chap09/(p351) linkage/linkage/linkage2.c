extern int all_files;

void sub(void)
{
	all_files = 10;
}
