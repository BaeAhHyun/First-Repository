#include <stdio.h>

int main(void)
{
	int temp;

	printf("temp = %d\n", temp);
}
