int z;
