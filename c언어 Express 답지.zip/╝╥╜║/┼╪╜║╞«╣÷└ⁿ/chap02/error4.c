#include <stdio.h>

int main(void)
{
	printf("Hey!");			// ��
	printf("Good Morning");		// ��
	return 0;
}